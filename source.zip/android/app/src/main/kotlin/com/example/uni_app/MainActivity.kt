package com.example.uni_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    // Awesome Notifications handles boot receivers and notification scheduling internally
    // No custom MethodChannel or boot handling needed
}
