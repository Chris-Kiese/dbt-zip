#!/usr/bin/sh
set -e

PUSH_ENABLED=false
REALESAE_SOURCE_CODE=false

for arg in "$@"
do
  if [ "$arg" = "--release" ]; then
    PUSH_ENABLED=true
  fi
  if [ "$arg" = "--source" ]; then
    REALESAE_SOURCE_CODE=true
  fi
done


echo "Building the apk..."
docker build -t uni_app .

echo "Running the apk..."
docker run -d --name uni_app uni_app /bin/true

echo "Copying the apk..."
docker cp uni_app:/app/build/app/outputs/flutter-apk/app-release.apk ./dbt.apk

echo "Removing the container and image..."
docker rm -f uni_app
docker rmi uni_app

echo "Zipping the apk..."
zip -r dbt.zip dbt.apk

echo "Copying to release repo"
cp dbt.zip ../dbt-zip/dbt.zip

if [ "$REALESAE_SOURCE_CODE" = true ]; then
    echo "Zipping source code..."
    zip -r source.zip .

    echo "Copying to release repo"
    cp source.zip ../dbt-zip/source.zip
fi

if [ "$PUSH_ENABLED" = true ]; then
    echo "Pushing changes to release repo"
    cd ../dbt-zip
    git add .
    git commit -m "New Version"
    git push
fi

cd ../uni_app

echo "Done"