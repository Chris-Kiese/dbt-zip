import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uni_app/const/styles.dart';
import 'package:uni_app/model/dbt/dbt.dart';
import 'package:uni_app/provider/dbt_repository.dart';
import 'package:uni_app/provider/screen_state_provider.dart';
import 'package:uni_app/model/enums/screen_state.dart';
import 'package:uni_app/view/widgets/explanation_label.dart';
import 'package:uni_app/const/selections.dart';
import 'package:uni_app/const/texts.dart';

class DbtForm extends ConsumerStatefulWidget {
  const DbtForm({super.key, this.dbt});

  final Dbt? dbt;

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _DbtFormState();
}

class _DbtFormState extends ConsumerState<DbtForm> {
  double _dissociation = 0;
  double _anxiety = 0;
  int _placeholderValue = 0;
  bool _touched = false;
  bool _initialized = false;
  String _feeling = feelingList.first;
  final commentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(dbtRepositoryProvider.notifier);

    //Set initial values to those of given dbt if it exists.
    if (widget.dbt != null && !_initialized) {
      setState(() {
        _initialized = true;
        _dissociation = widget.dbt?.dissociation.toDouble() ?? 0;
        _anxiety = widget.dbt?.anxiety.toDouble() ?? 0;
        _feeling = widget.dbt?.feeling ?? feelingList.first;
      });
    } else if (widget.dbt == null &&
        !_initialized) {
      setState(() {
        _initialized = true;
        commentController.text = '';
      });
    }

    return Form(
      child: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
            child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 10),
                const ExplanationLabel(label: labelDissociation, explanation: dissociationExplanation),
                Slider(
                    min: 0.0,
                    max: 10.0,
                    divisions: 10,
                    value: _dissociation,
                    label: _dissociation.toInt().toString(),
                    onChanged: ((value) => setState(() {
                          _dissociation = value;
                          _touched = true;
                        }))),
                const SizedBox(height: 10),
                const ExplanationLabel(label: labelAnxiety, explanation: anxietyExplanation),
                Slider(
                    min: 0.0,
                    max: 10.0,
                    divisions: 10,
                    value: _anxiety,
                    label: _anxiety.toInt().toString(),
                    onChanged: ((value) => setState(() {
                          _anxiety = value;
                          _touched = true;
                        }))),
                const SizedBox(height: 10),
                const ExplanationLabel(label: labelMood, explanation: moodExplanation),
                const SizedBox(height: 10),
                DropdownMenu<int>(
                  width: 200,
                  initialSelection: _placeholderValue,
                  label: const Text(labelMood),
                  onSelected: (value) => setState(() {
                    if (value == null) return;
                    _placeholderValue = value;
                    _touched = true;
                  }),
                  dropdownMenuEntries: moodMapping.entries
                      .map<DropdownMenuEntry<int>>(
                          (e) => DropdownMenuEntry<int>(
                            value: e.key,
                            label: e.value,
                          ))
                      .toList(),
                ),
                const SizedBox(height: 20),
                DropdownMenu<String>(
                  width: 200,
                  initialSelection: _feeling,
                  label: const Text(labelEmotion),
                  onSelected: (value) => setState(() {
                    if (value == null) return;
                    _feeling = value;
                    _touched = true;
                  }),
                  dropdownMenuEntries: feelingList
                      .map<DropdownMenuEntry<String>>(
                          (e) => DropdownMenuEntry<String>(value: e, label: e))
                      .toList(),
                ),
                const SizedBox(height: 10),
                const Text(usedSkillsHint),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    maxLines: 2,
                    style: const TextStyle(fontSize: 20),
                    controller: commentController,
                    decoration: InputDecoration(
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: primaryColor!)),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: primaryColor!)),
                        focusColor: primaryColor,
                        hoverColor: primaryColor),
                  ),
                ),
                //const Spacer(),
                const SizedBox(height: 10),
                ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            WidgetStateProperty.all<Color>(primaryColor!)),
                    onPressed: () async {
                      await _addOrUpdate(
                          repo, widget.dbt, commentController.text);
                      ref
                          .read(screenStateNotifierProvider.notifier)
                          .setScreenState(ScreenState.details);
                    },
                    child: widget.dbt == null
                        ? const Text(save,
                            style: TextStyle(color: Colors.black))
                        : const Text(update,
                            style: TextStyle(color: Colors.black))),
              ]),
        ),
      ),
    ));
  }

  _add(DbtRepository repo, String? comment) async => await repo.add(
      dissociation: _dissociation.toInt(),
      anxiety: _anxiety.toInt(),
      placeholderValue: _placeholderValue,
      feeling: _feeling,
      comment: comment);

  _update(DbtRepository repo, Dbt dbt, String? comment) async =>
      await repo.update(dbt,
          dissociation: _dissociation.toInt(),
          anxiety: _anxiety.toInt(),
          placeholderValue: _placeholderValue,
          feeling: _feeling,
          comment: comment);

  _addOrUpdate(DbtRepository repo, Dbt? dbt, String? comment) async {
    if (!_touched) {
      return null;
    }

    if (dbt == null) {
      await _add(repo, comment);
    } else {
      await _update(repo, dbt, comment);
    }
  }
}
