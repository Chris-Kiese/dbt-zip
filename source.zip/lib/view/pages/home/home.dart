import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uni_app/model/enums/screen_state.dart';
import 'package:uni_app/model/dbt/dbt.dart';
import 'package:uni_app/provider/date_provider.dart';
import 'package:uni_app/provider/dbt_repository.dart';
import 'package:uni_app/provider/notification_service_provider.dart';
import 'package:uni_app/provider/screen_state_provider.dart';
import 'package:uni_app/view/pages/home/screens/dbt/dbt.dart';
import 'package:uni_app/view/pages/home/forms/dbt.dart';
import 'package:uni_app/view/pages/home/screens/statistics/statistics.dart';
import 'package:uni_app/view/widgets/bottom_bar.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  //Current date as default

  @override
  Widget build(BuildContext context) {
    final DateTime selectedDate = ref.watch(dateNotifierProvider);
    final ScreenState screen = ref.watch(screenStateNotifierProvider);

    return Scaffold(
        appBar: AppBar(
          title: const Text('DBT App'),
          backgroundColor: Theme.of(context).primaryColor,
          centerTitle: true,
          actions: [
            /*
          _canEdit(dbt, screen) ? IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              ref.read(screenStateNotifierProvider.notifier).setScreenState(ScreenState.form);
            },
          ) : const SizedBox(width: 0, height: 0,),
          */
            _canCancel(screen)
                ? IconButton(
                    icon: const Icon(Icons.cancel),
                    onPressed: () {
                      ref
                          .read(screenStateNotifierProvider.notifier)
                          .setScreenState(ScreenState.details);
                    },
                  )
                : const SizedBox(
                    width: 0,
                    height: 0,
                  ),
            _canOpenSettings(screen)
                ? PopupMenuButton<String>(onSelected: (String choice) async {
                    switch (choice) {
                      case 'Daten exportieren':
                        ref
                            .read(dbtRepositoryProvider.notifier)
                            .exportXlxsData();
                        break;
                      case 'Daten speichern':
                        try {
                          await ref
                              .read(dbtRepositoryProvider.notifier)
                              .saveXlxsFile();
                          // Show success message
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Datei erfolgreich gespeichert'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          }
                        } catch (e) {
                          // Show error message
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Fehler beim Speichern: $e'),
                                duration: const Duration(seconds: 3),
                              ),
                            );
                          }
                        }
                        break;
                      case 'Sofortige Benachrichtigungen testen':
                        try {
                          final notificationService = ref.read(notificationServiceProvider);
                          await notificationService.sendImmediateTestNotification();
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Test-Benachrichtigung gesendet'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          }
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Fehler: $e'),
                                duration: const Duration(seconds: 3),
                              ),
                            );
                          }
                        }
                        break;
                      case 'Geplante Benachrichtigungen testen':
                        try {
                          final notificationService = ref.read(notificationServiceProvider);
                          await notificationService.sendScheduledTestNotification();
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Geplante Test-Benachrichtigung in 30'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          }
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Fehler: $e'),
                                duration: const Duration(seconds: 3),
                              ),
                            );
                          }
                        }
                        break;
                      default:
                        break;
                    }
                  }, itemBuilder: (BuildContext context) {
                    return {
                      //'Daten exportieren',
                      'Daten speichern',
                      //'Sofortige Benachrichtigungen testen',
                      //'Geplante Benachrichtigungen testen',
                    }.map((String choice) {
                      return PopupMenuItem<String>(
                        value: choice,
                        child: Text(choice),
                      );
                    }).toList();
                  })
                : const SizedBox(
                    width: 0,
                    height: 0,
                  ),
          ],
        ),
        body: _getScreen(screen, ref),
        bottomNavigationBar: const CustomBottomBar(),
        floatingActionButton: _canAdd(screen, selectedDate)
            ? FloatingActionButton(
                onPressed: () {
                  ref
                      .read(screenStateNotifierProvider.notifier)
                      .setScreenState(ScreenState.form);
                },
                child: const Icon(Icons.add),
              )
            : null);
  }

  bool _canEdit(Dbt? dbt, ScreenState screen) =>
      screen == ScreenState.details &&
      dbt?.date == DateUtils.dateOnly(DateTime.now());
  bool _canAdd(ScreenState screen, DateTime selectedDate) =>
      screen == ScreenState.details &&
      selectedDate == DateUtils.dateOnly(DateTime.now());
  bool _canOpenSettings(ScreenState screen) => screen != ScreenState.form;
  bool _canCancel(ScreenState screen) => screen == ScreenState.form;

  Widget _getScreen(ScreenState screen, WidgetRef ref) {
    switch (screen) {
      case ScreenState.form:
        return DbtForm(); // Add return statement
      case ScreenState.details:
        return const DbtView();
      case ScreenState.statistics:
        return const Statistics();
      default:
        return const DbtView();
    }
  }
}
