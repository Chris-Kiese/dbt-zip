import 'package:flutter/material.dart';
import 'package:scrollable_table_view/scrollable_table_view.dart';
import 'package:uni_app/const/texts.dart';
import 'package:uni_app/model/dbt/dbt.dart';

List<Widget> buildContent(DbtSummary? summary, MediaQueryData queryData,
    BuildContext context) {
  if (summary == null || summary.dbts.isEmpty) {
    return [const Text(noEntryText)];
  }

  return [
    Expanded(
      child: buildTable(summary.dbts, queryData.size, context),
    ),
  ];
}

Widget buildTable(List<Dbt> dbts, Size size, BuildContext context) =>
    ConstrainedBox(
      constraints: BoxConstraints(
        maxHeight: size.height,
        maxWidth: size.width,
      ),
      child: ScrollableTableView(
          headers: [timeHeader, dissociationHeader, anxietyHeader, emotionHeader]
              .map((e) => TableViewHeader(label: e))
              .toList(),
          rows: buildRows(dbts, context)),
    );

List<TableViewRow> buildRows(List<Dbt> dbts, BuildContext context) => [
      for (var dbt in dbts)
        TableViewRow(
          onTap: dbt.comment != null && dbt.comment!.isNotEmpty
              ? () {
                  // Show popup when row is tapped and has comment
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text(skillsDialogTitle),
                      content: Text(dbt.comment ?? ''),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text(close),
                        ),
                      ],
                    ),
                  );
                }
              : null,
          cells: [
            TableViewCell(
                child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                    '${dbt.date.hour.toString().padLeft(2, '0')}:${dbt.date.minute.toString().padLeft(2, '0')}'),
                Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: Icon(
                    Icons.note,
                    size: 16,
                    color: hasComment(dbt.comment)
                        ? null  // Use default color
                        : Colors.transparent,
                  ),
                ),
              ],
            )),
            TableViewCell(child: Text(dbt.dissociation.toString())),
            TableViewCell(child: Text(dbt.anxiety.toString())),
            TableViewCell(child: Text(dbt.feeling ?? '')),
            
          ],
        ),
    ];

bool hasComment(String? comment) => comment != null && comment.isNotEmpty;

String formatDate(DateTime date) =>
    '${date.day}.${date.month}.${date.year - 2000}';

class DbtDataTableSource extends DataTableSource {
  final List<Dbt> dbts;

  DbtDataTableSource(this.dbts);

  @override
  DataRow? getRow(int index) {
    final dbt = dbts[index];
    return DataRow.byIndex(index: index, cells: [
      DataCell(Text(
          '${dbt.date.hour.toString().padLeft(2, '0')}:${dbt.date.minute.toString().padLeft(2, '0')}')),
      DataCell(Text(dbt.dissociation.toString())),
      DataCell(Text(dbt.anxiety.toString())),
      DataCell(Text(dbt.feeling ?? '')),
    ]);
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => 0;

  @override
  int get selectedRowCount => dbts.length;
}
