import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uni_app/const/texts.dart';
import 'package:uni_app/model/dbt/dbt.dart';
import 'package:uni_app/provider/date_provider.dart';
import 'package:uni_app/provider/dbt_repository.dart';
import 'package:uni_app/view/pages/home/screens/dbt/widgets.dart';

class DbtView extends ConsumerWidget {
  const DbtView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final DateTime selectedDate =
        ref.watch(dateNotifierProvider); //Selected date from provider
    final List<DateTime> availableDates = ref
        .watch(dbtRepositoryProvider)
        .map((e) => DateUtils.dateOnly(e.date))
        .toSet()
        .toList(); //List of all available dates that can be selected
    final DbtSummary? summary = ref
        .watch(dbtRepositoryProvider)
        .where((element) => DateUtils.dateOnly(element.date) == selectedDate)
        .firstOrNull; //Summary of the selected date
    final MediaQueryData queryData = MediaQuery.of(context);

    return Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(
            height: 20,
            width: 6000,
          ),
          GestureDetector(
            onTap: () async {
              final DateTime? newDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2024),
                  lastDate: DateTime.now(),
                  locale: const Locale('de', 'DE'),
                  //Allow to pick either dates with existing entrys or the current date.
                  selectableDayPredicate: (date) =>
                      availableDates.contains(DateUtils.dateOnly(date)) ||
                      DateUtils.dateOnly(date) ==
                          DateUtils.dateOnly(DateTime.now()),
                  helpText: datePickerHelpText,
                  cancelText: datePickerCancelText,
                  confirmText: datePickerConfirmText);

              //If a date was chosen change the provider value.
              if (newDate != null) {
                ref
                    .read(dateNotifierProvider.notifier)
                    .setDate(DateUtils.dateOnly(newDate));
              }
            },
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(
                  '${selectedDate.day}.${selectedDate.month}.${selectedDate.year}',
                  style: const TextStyle(fontSize: 22, color: Colors.black)),
              const SizedBox(width: 10),
              const Icon(
                Icons.calendar_month,
                size: 26,
              )
            ]),
          ),
          ...buildContent(summary, queryData, context),
        ]);
  }
}
