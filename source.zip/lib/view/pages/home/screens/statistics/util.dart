import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:uni_app/const/styles.dart';
import 'package:uni_app/model/enums/chart_data.dart';
import 'package:uni_app/model/enums/chart_range.dart';
import 'package:uni_app/model/dbt/dbt.dart';

///Utility class for storing the [min] & [max] values of an axis for the chart used in the statistics page.
class Range {
  double min;
  double max;

  Range(this.min, this.max);
}

///Calculates the range of the x-axis for the chart in the statistics page, based on the selected [ChartRange].
///The [oldestDbt] and [newestDbt] are optional parameters to calculate the range based on the oldest and newest dbt in the database.
///[oldestDbt] and [newestDbt] are used to calculate the range for the [ChartRange.all] option.
Range calculateXRange(ChartRange range, int month,
    {required DateTime oldestDbt, required DateTime newestDbt}) {
  switch (range) {
    case ChartRange.week:
      return Range(0, 6);
    case ChartRange.month:
      return Range(0, monthLength(month).toDouble());
    case ChartRange.year:
      return Range(0, 364);
    case ChartRange.all:
      int difference = newestDbt.difference(oldestDbt).inDays;
      return Range(0, difference.toDouble());
  }
}

///Utility class for storing the chart spots for dbt dissociation & anxiety.
class ChartSpots {
  List<FlSpot> dissociationSpots;
  List<FlSpot> anxietySpots;
  List<FlSpot> placeholderValueSpots;

  ChartSpots(
      this.dissociationSpots, this.anxietySpots, this.placeholderValueSpots);
}

///Calculate the chart spots of [Dbts] between the [startDate] and [endDate].
ChartSpots calculateSpots(
    {required DbtSummaries summaries,
    required DateTime startDate,
    required DateTime endDate}) {
  final DbtSummaries filteredSummaries =
      summaries.where((e) => isBetween(e.date, startDate, endDate)).toList();
  final List<FlSpot> dissociationSpots = [];
  final List<FlSpot> anxietySpots = [];
  final List<FlSpot> placeholderValueSpots = [];

  for (DbtSummary summary in filteredSummaries) {
    final dayDifference = summary.date.difference(startDate).inDays;
    dissociationSpots
        .add(FlSpot(dayDifference.toDouble(), summary.dissociation.toDouble()));
    anxietySpots
        .add(FlSpot(dayDifference.toDouble(), summary.anxiety.toDouble()));
    placeholderValueSpots.add(
        FlSpot(dayDifference.toDouble(), summary.placeholderValue.toDouble()));
  }

  return ChartSpots(dissociationSpots, anxietySpots, placeholderValueSpots);
}

bool isBetween(DateTime date, DateTime start, DateTime end) {
  return (date.isAfter(start) || date == start) &&
      (date.isBefore(end) || date == end);
}

///Calculates the title of the chart based on the selected [ChartRange] and the provided [value].
Widget calculateTitle(ChartRange range, double value, DbtSummaries summaries) {
  bool isLeapYear = DateTime.now().year % 4 == 0;
  switch (range) {
    case ChartRange.week:
      return Text(weekTitle(value));
    case ChartRange.month:
      return Text(monthTitle(value));
    case ChartRange.year:
      return Text(yearTitle(value, isLeapYear));
    case ChartRange.all:
      //Use first dbt as first label
      return Text(wholeRangeTitle(value, summaries));
  }
}

///Returns the title of the chart based on the selected [ChartRange].
bottomTitles(ChartRange range, DbtSummaries summaries) =>
    (double value, TitleMeta meta) => SideTitleWidget(
          axisSide: meta.axisSide,
          child: calculateTitle(range, value, summaries),
        );

///Returns the title of the weekday based on the provided day [value].
String weekTitle(double value) {
  switch (value.toInt()) {
    case 0:
      return 'M0';
    case 1:
      return 'DI';
    case 2:
      return 'MI';
    case 3:
      return 'DO';
    case 4:
      return 'FR';
    case 5:
      return 'SA';
    case 6:
      return 'SO';
    default:
      return '';
  }
}

///Returns the title of the month day based on the provided day [value].
String monthTitle(double value) {
  switch (value.toInt()) {
    case 0:
      return '1';
    case 3:
      return '4';
    case 6:
      return '7';
    case 9:
      return '10';
    case 12:
      return '13';
    case 15:
      return '16';
    case 18:
      return '19';
    case 21:
      return '22';
    case 25:
      return '26';
    case 28:
      return '29';
    case 30:
      return '31';
    default:
      return '';
  }
}

///Returns the title of the year based on the provided day [value].
String yearTitle(double value, bool leapYear) {
  //Return the month name based on the index for a leap year.
  if (leapYear) {
    switch (value.toInt()) {
      case 0:
        return 'Jan';
      case 60:
        return 'Mär';
      case 121:
        return 'Mai';
      case 182:
        return 'Jul';
      case 244:
        return 'Sep';
      case 335:
        return 'Dez';
    }
  }

  //Return the month name based on the index for a normal year.
  switch (value.toInt()) {
    case 0:
      return 'Jan';
    case 59:
      return 'Mär';
    case 120:
      return 'Mai';
    case 181:
      return 'Jul';
    case 243:
      return 'Sep';
    case 334:
      return 'Dez';
    default:
      return '';
  }
}

String wholeRangeTitle(double value, DbtSummaries summaries) {
  if (summaries.isEmpty) return '';
  if (value == 0) {
    return '${summaries.first.date.month}.${summaries.first.date.year - 2000}';
  }
  if (value == (summaries.length / 2).round()) {
    return '${summaries[summaries.length ~/ 2].date.month}.${summaries[summaries.length ~/ 2].date.year - 2000}';
  }
  if (value == (summaries.length - 1)) {
    return '${summaries.last.date.month}.${summaries.last.date.year - 2000}';
  }
  return '';
}

///Returns the length of the month based on the provided [month] index.
int monthLength(int month) {
  if (month == 2) return 28;
  if (month == 4 || month == 6 || month == 9 || month == 11) return 30;
  return 31;
}

///Returns the name of the month based on the provided [month] index.
String getMonth(int month) {
  switch (month) {
    case 1:
      return 'Januar';
    case 2:
      return 'Februar';
    case 3:
      return 'März';
    case 4:
      return 'April';
    case 5:
      return 'Mai';
    case 6:
      return 'Juni';
    case 7:
      return 'Juli';
    case 8:
      return 'August';
    case 9:
      return 'September';
    case 10:
      return 'Oktober';
    case 11:
      return 'November';
    case 12:
      return 'Dezember';
    default:
      return '';
  }
}

///Returns the last day of the month of the provided date.
DateTime lastDayOfMonth(DateTime date) => date.month < 12
    ? DateTime(date.year, date.month + 1, 0)
    : DateTime(date.year + 1, 1, 0);

///Returns the first day of the month.
DateTime firstDayOfMonth(DateTime date) => DateTime(date.year, date.month, 1);

///Returns the start of the week of the provided date.
DateTime startOfWeek(DateTime date) =>
    DateTime(date.year, date.month, date.day - date.weekday + 1);

///Returns the end of the week of the provided date.
DateTime endOfWeek(DateTime date) =>
    DateTime(date.year, date.month, date.day + (7 - date.weekday));

///Returns the start of the year of the provided date.
DateTime startOfYear(DateTime date) => DateTime(date.year, 1, 1);

///Returns the end of the year of the provided date.
DateTime endOfYear(DateTime date) => DateTime(date.year, 12, 31);

///Return the [LineChartBarData] based on the [ChartData]
List<LineChartBarData> getLineChartBarData(
    ChartData selectedData, ChartSpots spots) {
  List<LineChartBarData> chartBarData = [];
  if (selectedData == ChartData.anxiety || selectedData == ChartData.all) {
    //Add anxiety
    chartBarData.add(LineChartBarData(
      color: anxietyColor,
      spots: spots.anxietySpots,
      isCurved: true,
      barWidth: 4,
      isStrokeCapRound: true,
      belowBarData: BarAreaData(show: false),
    ));
  }
  if (selectedData == ChartData.dissociation || selectedData == ChartData.all) {
    //Add dissociation
    chartBarData.add(LineChartBarData(
      color: dissociationColor,
      spots: spots.dissociationSpots,
      isCurved: true,
      barWidth: 4,
      isStrokeCapRound: true,
      belowBarData: BarAreaData(show: false),
    ));
  }
  return chartBarData;
}

//TODO: Refactor to make it work again.
///Returns the [LineTouchData] and tooltips based on the provided [summaries], [selectedData] and [startDate].
LineTouchData getLineTouchData(
    DbtSummaries summaries, ChartData selectedData, DateTime startDate) {
  return LineTouchData(
      touchTooltipData: LineTouchTooltipData(
    fitInsideVertically: true,
    fitInsideHorizontally: true,
    maxContentWidth: 200,
    getTooltipItems: (touchedSpots) {
      List<LineTooltipItem?> tooltipItems = [];
      List<double> alreadyUsedValues = [];
      for (var touchedSpot in touchedSpots) {
        DbtSummary? summary =
            getSummaryFromX(summaries, touchedSpot.x, startDate);
        if (alreadyUsedValues.contains(touchedSpot.x)) {
          tooltipItems.add(LineTooltipItem(
              formatData(summary), const TextStyle(color: Colors.white)));
          continue;
        }
        tooltipItems.add(LineTooltipItem(
            selectedData == ChartData.all
                ? '${summary?.date.day}.${summary?.date.month}.${summary?.date.year}'
                : '${summary?.date.day}.${summary?.date.month}.${summary?.date.year}\n\n${formatData(summary)}',
            const TextStyle(color: Colors.white)));
        alreadyUsedValues.add(touchedSpot.x);
      }
      return tooltipItems;
    },
  ));
}

String formatData(DbtSummary? summary) {
  String data =
      'Anspannung: ${summary?.anxiety}\nDissoziation: ${summary?.dissociation}';
  return data;
}

List<DbtSummary> getSummaries(List<Dbt> dbts) {
  final List<DbtSummary> summaries = [];
  for (Dbt dbt in dbts) {
    final DbtSummary? summary = summaries
        .where((e) => DateUtils.isSameDay(e.date, dbt.date))
        .firstOrNull;
    if (summary == null) {
      summaries.add(DbtSummary(date: dbt.date, dbts: [dbt]));
    } else {
      summary.dbts.add(dbt);
    }
  }
  return summaries;
}

///Return the dbt for the provided [xValue] based on the provided [summaries] and [startDate].
DbtSummary? getSummaryFromX(
    List<DbtSummary> summaries, double x, DateTime startDate) {
  final DateTime date = startDate.add(Duration(days: x.toInt()));
  return summaries.firstWhere((e) => e.date == date);
}
