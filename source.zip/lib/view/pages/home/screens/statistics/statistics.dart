import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uni_app/const/styles.dart';
import 'package:uni_app/model/enums/chart_data.dart';
import 'package:uni_app/model/enums/chart_range.dart';
import 'package:uni_app/provider/dbt_repository.dart';
import 'package:uni_app/model/dbt/dbt.dart';
import 'package:uni_app/view/pages/home/screens/statistics/util.dart';
import 'package:uni_app/const/texts.dart';

class Statistics extends ConsumerStatefulWidget {
  const Statistics({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _StatisticsState();
}

class _StatisticsState extends ConsumerState<Statistics> {
  ChartRange selectedRange = ChartRange.week;
  ChartData selectedData = ChartData.all;
  DateTime startDate = startOfWeek(DateTime.now());
  DateTime endDate = endOfWeek(DateTime.now());

  @override
  Widget build(BuildContext context) {
    final MediaQueryData queryData = MediaQuery.of(context);

    final DbtSummaries summaries = ref.watch(dbtRepositoryProvider);
    summaries.sort((a, b) => a.date.compareTo(b.date));

    final spots = calculateSpots(
        summaries: summaries, startDate: startDate, endDate: endDate);
    final xRange = calculateXRange(selectedRange, startDate.month,
        oldestDbt: summaries.isEmpty ? DateTime.now() : summaries.first.date,
        newestDbt: summaries.isEmpty ? DateTime.now() : summaries.last.date);

    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 20),
          Row(
            children: [
              SizedBox(width: queryData.size.width * 0.05),
              DropdownMenu(
                  initialSelection: selectedRange,
                  width: queryData.size.width * 0.45,
                  label: const Text(timeRangeLabel),
                  onSelected: (ChartRange? range) {
                    if (range == null) return;

                    setState(() {
                      selectedRange = range;
                      switch (range) {
                        case ChartRange.week:
                          startDate = startOfWeek(DateTime.now());
                          endDate = endOfWeek(DateTime.now());
                          break;
                        case ChartRange.month:
                          startDate = firstDayOfMonth(DateTime.now());
                          endDate = lastDayOfMonth(DateTime.now());
                          break;
                        case ChartRange.year:
                          startDate = startOfYear(DateTime.now());
                          endDate = endOfYear(DateTime.now());
                          break;
                        case ChartRange.all:
                          startDate = summaries.isEmpty
                              ? DateTime.now()
                              : summaries.first.date;
                          endDate = summaries.isEmpty
                              ? DateTime.now()
                              : summaries.last.date;
                          break;
                      }
                    });
                  },
                  dropdownMenuEntries: const [
                    DropdownMenuEntry(value: ChartRange.week, label: weekLabel),
                    DropdownMenuEntry(value: ChartRange.month, label: monthLabel),
                    //Commented out because the data is too samll -> not really usable.
                    //DropdownMenuEntry(value: ChartRange.year, label: yearLabel),
                    //DropdownMenuEntry(value: ChartRange.all, label: totalLabel)
                  ]),
              DropdownMenu(
                  initialSelection: selectedData,
                  width: queryData.size.width * 0.45,
                  label: const Text(dataLabel),
                  onSelected: (ChartData? data) {
                    if (data == null) return;
                    setState(() {
                      selectedData = data;
                    });
                  },
                  dropdownMenuEntries: const [
                    DropdownMenuEntry(value: ChartData.all, label: allDataLabel),
                    DropdownMenuEntry(value: ChartData.anxiety, label: anxietyHeader),
                    DropdownMenuEntry(value: ChartData.dissociation, label: dissociationHeader),
                  ]),
            ],
          ),
          const SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              (selectedData == ChartData.anxiety ||
                      selectedData == ChartData.all)
                  ? Text('Anspannung', style: TextStyle(color: anxietyColor))
                  : const SizedBox(width: 0),
              selectedData == ChartData.all
                  ? const Text(' / ')
                  : const SizedBox(width: 0),
              (selectedData == ChartData.dissociation ||
                      selectedData == ChartData.all)
                  ? Text('Dissoziation',
                      style: TextStyle(color: dissociationColor))
                  : const SizedBox(width: 0),
            ],
          ),
          SizedBox(
            height: 300,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(0, 0, 20, 0),
              child: LineChart(LineChartData(
                  backgroundColor: Colors.grey[100],
                  titlesData: FlTitlesData(
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                          drawBelowEverything: false),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 30,
                          interval: 1,
                          getTitlesWidget:
                              bottomTitles(selectedRange, summaries),
                        ),
                      )),
                  minY: 0,
                  maxY: 10,
                  minX: xRange.min,
                  maxX: xRange.max,
                  gridData: const FlGridData(show: false),
                  lineBarsData: getLineChartBarData(selectedData, spots),
                  lineTouchData:
                      getLineTouchData(summaries, selectedData, startDate))),
            ),
          ),
        ]));
  }
}
