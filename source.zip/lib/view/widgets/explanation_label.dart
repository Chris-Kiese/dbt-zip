import 'package:flutter/material.dart';

class ExplanationLabel extends StatelessWidget {
  final String label;
  final String explanation;

  const ExplanationLabel({
    super.key,
    required this.label,
    required this.explanation,
  });

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.center,children: [Text(label),GestureDetector(
      onTapDown: (details) {
        final RenderBox overlay = Overlay.of(context).context.findRenderObject() as RenderBox;
        showMenu(
          context: context,
          position: RelativeRect.fromRect(
            details.globalPosition & const Size(40, 40),
            Offset.zero & overlay.size,
          ),
          items: [
            PopupMenuItem(
              enabled: false,
              child: Text(
                explanation,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
        );
      },
      child: const Padding(
        padding: EdgeInsets.only(left: 8.0),
        child: Icon(Icons.help_outline, size: 20),
      ),
    )]
    );
  }
} 