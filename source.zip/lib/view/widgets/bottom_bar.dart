import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uni_app/const/styles.dart';
import 'package:uni_app/model/enums/screen_state.dart';
import 'package:uni_app/provider/screen_state_provider.dart';

class CustomBottomBar extends ConsumerWidget {
  const CustomBottomBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ScreenState screen = ref.watch(screenStateNotifierProvider);

    return BottomAppBar(
      color: primaryColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            icon: Icon(
              Icons.bar_chart,
              color: _getColor([ScreenState.statistics], screen),
              size: 40.0,
            ),
            onPressed: () {
              if (screen == ScreenState.statistics) return;
              ref
                  .read(screenStateNotifierProvider.notifier)
                  .setScreenState(ScreenState.statistics);
            },
          ),
          IconButton(
            icon: Icon(
              Icons.home,
              color: _getColor([ScreenState.details, ScreenState.form], screen),
              size: 40.0,
            ),
            onPressed: () {
              if (screen == ScreenState.form || screen == ScreenState.details) {
                return;
              }
              ref
                  .read(screenStateNotifierProvider.notifier)
                  .setScreenState(ScreenState.details);
            },
          ),
        ],
      ),
    );
  }

  Color? _getColor(List<ScreenState> screens, ScreenState currentScreen) =>
      screens.contains(currentScreen)
          ? btmBarActivatedColor
          : btmBarDeactivatedColor;
}
