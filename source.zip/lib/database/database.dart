import 'package:flutter/foundation.dart';
import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uni_app/model/dbt/dbt.dart';

late Isar db;

final schemas = [
  DbtSummarySchema,
];

Future<void> initDb() async {
  if(Isar.instanceNames.isEmpty) {
    final dir = await getApplicationDocumentsDirectory();
    db = await Isar.open(
      schemas,
      directory: dir.path,
      inspector: kDebugMode
      );
  }
}