
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';

const String SCHEDULED_NOTIFICATION_TITLE = 'DBT Erinnerung';
const String SCHEDULED_NOTIFICATION_BODY = 'Bitte Kurz Anspannung & Dissoziation eintragen';

/// Top-level callback dispatcher for WorkManager
/// This function is called by WorkManager when a task executes
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      // Initialize AwesomeNotifications in the isolate
      await AwesomeNotifications().initialize(
        'resource://mipmap/ic_launcher',
        [
          NotificationChannel(
            channelKey: 'hourly_reminders',
            channelName: 'Hourly Reminders',
            channelDescription: 'Hourly reminders for DBT app',
            channelGroupKey: 'dbt_channel_group',
            defaultColor: Colors.blue,
            ledColor: Colors.white,
            importance: NotificationImportance.High,
            channelShowBadge: true,
            playSound: true,
            enableVibration: true,
          ),
        ],
        channelGroups: [
          NotificationChannelGroup(
            channelGroupKey: 'dbt_channel_group',
            channelGroupName: 'DBT Notifications',
          ),
        ],
      );

      // Get the hour from input data or task name
      int targetHour = 8;
      String? hourStr = inputData?['hour'] as String?;
      
      if (hourStr != null) {
        targetHour = int.tryParse(hourStr) ?? 8;
      } else {
        // Fallback: try to extract hour from task name
        if (task.startsWith('hourly_notification_')) {
          String hourPart = task.replaceFirst('hourly_notification_', '');
          targetHour = int.tryParse(hourPart) ?? 8;
        }
      }

      // Map hour (8-21) to notification ID (0-13)
      int notificationId = targetHour - 8;

      // Display the notification
      await AwesomeNotifications().createNotification(
        content: NotificationContent(
          id: notificationId,
          channelKey: 'hourly_reminders',
          title: SCHEDULED_NOTIFICATION_TITLE,
          body: SCHEDULED_NOTIFICATION_BODY,
          notificationLayout: NotificationLayout.Default,
          actionType: ActionType.Default,
        ),
      );

      // Reschedule this task for the next day (24 hours from now)
      DateTime now = DateTime.now();
      DateTime nextOccurrence = DateTime(now.year, now.month, now.day, targetHour, 0, 0);
      
      // If the target time has passed today, schedule for tomorrow
      if (nextOccurrence.isBefore(now) || nextOccurrence.isAtSameMomentAs(now)) {
        nextOccurrence = nextOccurrence.add(const Duration(days: 1));
      }
      
      Duration delay = nextOccurrence.difference(now);
      
      // Reschedule the task
      await Workmanager().registerOneOffTask(
        task,
        task,
        inputData: {'hour': targetHour.toString()},
        initialDelay: delay,
      );

      return Future.value(true);
    } catch (e) {
      print('Error in WorkManager callback: $e');
      return Future.value(false);
    }
  });
}

