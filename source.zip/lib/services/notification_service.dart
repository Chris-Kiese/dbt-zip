import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';
import 'package:uni_app/services/workmanager_callback.dart';

const String SCHEDULED_NOTIFICATION_TITLE = 'DBT Erinnerung';
const String SCHEDULED_NOTIFICATION_BODY = 'Bitte Kurz Anspannung & Dissoziation eintragen';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  static const String _channelKey = 'hourly_reminders';
  static const String _channelName = 'Hourly Reminders';
  static const String _channelDescription = 'Hourly reminders for DBT app';
  static const String _channelGroupKey = 'dbt_channel_group';
  static const String _channelGroupName = 'DBT Notifications';

  bool _initialized = false;

  /// Initialize the notification service
  Future<void> initialize() async {
    if (_initialized) return;

    // Initialize AwesomeNotifications with channel configuration
    await AwesomeNotifications().initialize(
      'resource://mipmap/ic_launcher',
      [
        NotificationChannel(
          channelKey: _channelKey,
          channelName: _channelName,
          channelDescription: _channelDescription,
          channelGroupKey: _channelGroupKey,
          defaultColor: Colors.blue,
          ledColor: Colors.white,
          importance: NotificationImportance.High,
          channelShowBadge: true,
          playSound: true,
          enableVibration: true,
        ),
      ],
      channelGroups: [
        NotificationChannelGroup(
          channelGroupKey: _channelGroupKey,
          channelGroupName: _channelGroupName,
        ),
      ],
    );

    // Set up notification listeners
    AwesomeNotifications().setListeners(
      onActionReceivedMethod: _onNotificationTapped,
      onNotificationCreatedMethod: _onNotificationCreated,
      onNotificationDisplayedMethod: _onNotificationDisplayed,
      onDismissActionReceivedMethod: _onNotificationDismissed,
    );

    // Request permissions
    await _requestPermissions();

    _initialized = true;
  }

  /// Request notification permissions
  Future<bool> _requestPermissions() async {
    bool isAllowed = await AwesomeNotifications().isNotificationAllowed();
    if (!isAllowed) {
      isAllowed = await AwesomeNotifications().requestPermissionToSendNotifications();
    }
    return isAllowed;
  }

  /// Initialize WorkManager
  Future<void> initializeWorkManager() async {
    await Workmanager().initialize(
      callbackDispatcher,
      isInDebugMode: false,
    );
  }

  /// Schedule hourly notifications from 8:00 to 21:00 using WorkManager
  Future<void> scheduleHourlyNotifications() async {
    await cancelAllNotifications();

    DateTime now = DateTime.now();

    for (int hour = 8; hour <= 21; hour++) {
      await _scheduleWorkManagerTask(hour, now);
    }
  }

  /// Schedule a WorkManager task for a specific hour
  Future<void> _scheduleWorkManagerTask(int targetHour, DateTime now) async {
    // Calculate the next occurrence of this hour
    DateTime targetTime = DateTime(now.year, now.month, now.day, targetHour, 0, 0);
    
    // If the target time has passed today, schedule for tomorrow
    if (targetTime.isBefore(now)) {
      targetTime = targetTime.add(const Duration(days: 1));
    }

    // Calculate delay until the target time
    Duration delay = targetTime.difference(now);

    // Create unique task name
    String taskName = 'hourly_notification_$targetHour';

    // Register one-time work request
    await Workmanager().registerOneOffTask(
      taskName,
      taskName,
      inputData: {'hour': targetHour.toString()},
      initialDelay: delay,
    );
  }

  /// Display notification immediately (called by WorkManager callback)
  Future<void> displayNotification(int notificationId) async {
    await AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: notificationId,
        channelKey: _channelKey,
        title: SCHEDULED_NOTIFICATION_TITLE,
        body: SCHEDULED_NOTIFICATION_BODY,
        notificationLayout: NotificationLayout.Default,
        actionType: ActionType.Default,
      ),
    );
  }

  /// Reschedule a specific hourly notification task after it completes
  /// This is called by WorkManager callback to schedule the next occurrence
  Future<void> rescheduleHourlyTask(int targetHour) async {
    DateTime now = DateTime.now();
    await _scheduleWorkManagerTask(targetHour, now);
  }

  Future<void> cancelAllNotifications() async {
    // Cancel all WorkManager tasks
    for (int hour = 8; hour <= 21; hour++) {
      String taskName = 'hourly_notification_$hour';
      await Workmanager().cancelByUniqueName(taskName);
    }
    // Also cancel any scheduled AwesomeNotifications (for cleanup)
    await AwesomeNotifications().cancelAll();
  }

  Future<void> cancelNotification(int id) async {
    // Map notification ID (0-13) back to hour (8-21)
    int hour = id + 8;
    String taskName = 'hourly_notification_$hour';
    await Workmanager().cancelByUniqueName(taskName);
    await AwesomeNotifications().cancel(id);
  }

  Future<void> rescheduleAfterBoot() async {
    await scheduleHourlyNotifications();
  }

  @pragma('vm:entry-point')
  static Future<void> _onNotificationTapped(ReceivedAction receivedAction) async {
    print('Notification tapped: ${receivedAction.id}');
  }

  @pragma('vm:entry-point')
  static Future<void> _onNotificationCreated(ReceivedNotification receivedNotification) async {
    print('Notification created: ${receivedNotification.id}');
  }

  @pragma('vm:entry-point')
  static Future<void> _onNotificationDisplayed(ReceivedNotification receivedNotification) async {
    print('Notification displayed: ${receivedNotification.id}');
  }

  @pragma('vm:entry-point')
  static Future<void> _onNotificationDismissed(ReceivedAction receivedAction) async {
    print('Notification dismissed: ${receivedAction.id}');
  }

  Future<List<NotificationModel>> getPendingNotifications() async {
    // Note: WorkManager doesn't provide a direct way to list scheduled tasks
    // This will only return notifications scheduled via AwesomeNotifications (if any)
    return await AwesomeNotifications().listScheduledNotifications();
  }

  Future<bool> areNotificationsEnabled() async {
    return await AwesomeNotifications().isNotificationAllowed();
  }

  Future<void> sendImmediateTestNotification() async {
    const String title = 'Test: Sofortige Benachrichtigung';
    const String body = 'Diese Benachrichtigung wurde sofort gesendet';

    await AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: 9999,
        channelKey: _channelKey,
        title: title,
        body: body,
        notificationLayout: NotificationLayout.Default,
        actionType: ActionType.Default,
      ),
    );
  }

  Future<void> sendScheduledTestNotification() async {
    const String title = 'Test: Geplante Benachrichtigung';
    const String body = 'Diese Benachrichtigung wurde 30 Sekunden später gesendet';

    String localTimeZone = await AwesomeNotifications().getLocalTimeZoneIdentifier();
    DateTime scheduledTime = DateTime.now().add(const Duration(seconds: 30));

    await AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: 9998,
        channelKey: _channelKey,
        title: title,
        body: body,
        notificationLayout: NotificationLayout.Default,
        actionType: ActionType.Default,
      ),
      schedule: NotificationCalendar(
        year: scheduledTime.year,
        month: scheduledTime.month,
        day: scheduledTime.day,
        hour: scheduledTime.hour,
        minute: scheduledTime.minute,
        second: scheduledTime.second,
        timeZone: localTimeZone,
        repeats: false,
      ),
    );
  }
}
