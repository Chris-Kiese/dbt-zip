import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:isar/isar.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:uni_app/database/database.dart';
import 'package:uni_app/model/dbt/dbt.dart';
import 'package:excel/excel.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

part 'dbt_repository.g.dart';

/// Repository used as cache for dbts stored in Database, as well as access database for CRUD funtionality.
@Riverpod(keepAlive: true)
class DbtRepository extends _$DbtRepository {
  final collection = db.DbtSummaries;

  @override
  DbtSummaries build() {
    load();
    return [];
  }

  Future<void> load() async {
    DbtSummaries dbts = await collection.where().findAll();
    state = [...dbts];
  }

  Future<void> add(
      {required int dissociation,
      required int anxiety,
      required int placeholderValue,
      required String feeling,
      String? comment}) async {
    final dbt = Dbt(
      dissociation: dissociation,
      anxiety: anxiety,
      placeholderValue: placeholderValue,
      feeling: feeling,
      comment: comment,
    );
    DbtSummary summary = getOrCreateSummary(dbt);

    await updateCollection(summary);
  }

  Future<void> update(Dbt dbt,
      {required int dissociation,
      required int anxiety,
      required int placeholderValue,
      required String feeling,
      String? comment}) async {
    dbt.update(
        dissociation: dissociation,
        anxiety: anxiety,
        placeholderValue: placeholderValue,
        feeling: feeling);
    DbtSummary? summary = getSummary(dbt.date);
    if (summary == null) {
      return; //TODO: show error message.
    }

    summary.updateDbt(dbt);

    await updateCollection(summary);
  }

  Future<void> delete(Dbt dbt) async {
    DbtSummary? summary = getSummary(dbt.date);
    if (summary == null) {
      return; //TODO: show error message.
    }

    summary.removeDbt(dbt);

    updateCollection(summary);
  }

  Future<void> deleteAll() async {
    List<int> ids = state.map((e) => e.id).toList();
    await db.writeTxn(() async {
      await collection.deleteAll(ids);
    });

    state = [];
  }

  //Write collection changes to database & notify listeners.
  Future<void> updateCollection(DbtSummary summary) async {
    await db.writeTxn(() async {
      await collection.put(
          summary); //Todo: check if existing data is actually replaced correctly.
    });

    //Notify listeners
    state.removeWhere((e) => e.date == summary.date);
    state = [...state, summary];
  }

  //Get the summary for the given date.
  DbtSummary? getSummary(DateTime date) =>
      state.where((e) => DateUtils.isSameDay(date, e.date)).firstOrNull;

  //Either create a new summary with the given dbt & comment or add the dbt & comment to the existing summary.
  DbtSummary getOrCreateSummary(Dbt dbt) {
    DbtSummary? summary = getSummary(dbt.date);

    if (summary != null) {
      summary.addDbt(dbt);
      return summary;
    }

    return DbtSummary(date: dbt.date, dbts: [dbt]);
  }

  void exportXlxsData() async {
    Uint8List? fileBytes = createXlxsFile();
    if (fileBytes == null) {
      return;
    }
    Share.shareXFiles(
      [XFile.fromData(fileBytes, name: 'dbt.xlsx')],
      fileNameOverrides: ['dbt_data.xlsx'],
    );
  }

  Future<void> saveXlxsFile() async {
    Uint8List? fileBytes = createXlxsFile();
    if (fileBytes == null) {
      throw Exception('Fehler beim Erstellen der Excel-Datei');
    }

    try {
      // Let user select a directory to save the file
      String? selectedDirectory = await FilePicker.platform.getDirectoryPath();
      
      if (selectedDirectory == null) {
        // User cancelled the directory selection
        throw Exception('Speichervorgang abgebrochen');
      }

      // Create the file path with timestamp to avoid conflicts
      String fileName = "dbt_data_${DateTime.now().millisecondsSinceEpoch}.xlsx";
      String filePath = "$selectedDirectory/$fileName";

      // Write the file
      File file = File(filePath);
      await file.writeAsBytes(fileBytes);

      // Show success message (you might want to use a snackbar or dialog)
      if (kDebugMode) {
        print("File saved successfully to: $filePath");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error saving file: $e");
      }
      // Re-throw the exception so the UI can handle it
      rethrow;
    }
  }

  Uint8List? createXlxsFile() {
    //Create Excel file
    Excel excel = Excel.createExcel();
    final sheetName = excel.getDefaultSheet() ?? 'Sheet1';

    //Set header
    excel[sheetName].appendRow([
      TextCellValue('Date'),
      TextCellValue('Time'),
      TextCellValue('Dissociation'),
      TextCellValue('Anxiety'),
      TextCellValue('Mood'),
      TextCellValue('Feeling'),
      TextCellValue('Ereignis')
    ]);

    //Sort data by date & add to excel file
    DbtSummaries summaries = state;
    
    if (summaries.isEmpty) {
      // Add a row indicating no data
      excel[sheetName].appendRow([
        TextCellValue('Keine Daten verfügbar'),
        TextCellValue(''),
        TextCellValue(''),
        TextCellValue(''),
        TextCellValue(''),
        TextCellValue(''),
        TextCellValue('')
      ]);
    } else {
      for (final summary in summaries) {
        summary.dbts.sort((a, b) => a.date.compareTo(b.date));
        for (final dbt in summary.dbts) {
          //TODO: add comment only to first entry of each day.
          excel[sheetName].appendRow(dbt.toCellValues());
        }
      }
    }

    //Save & share file as bytes
    var fileBytes = excel.save();
    if (fileBytes == null) {
      return null;
    }
    return Uint8List.fromList(fileBytes);
  }
}
