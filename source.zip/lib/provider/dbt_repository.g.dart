// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dbt_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$dbtRepositoryHash() => r'73bfa995ab3ea366883e13a98c37da92bde393f6';

/// Repository used as cache for dbts stored in Database, as well as access database for CRUD funtionality.
///
/// Copied from [DbtRepository].
@ProviderFor(DbtRepository)
final dbtRepositoryProvider =
    NotifierProvider<DbtRepository, List<DbtSummary>>.internal(
  DbtRepository.new,
  name: r'dbtRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$dbtRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DbtRepository = Notifier<List<DbtSummary>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
