import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'date_provider.g.dart';

@riverpod
class DateNotifier extends _$DateNotifier {
  @override
  DateTime build() => DateUtils.dateOnly(DateTime.now());

  void setDate(DateTime date) => state = date;
}