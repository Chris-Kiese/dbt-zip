import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:uni_app/services/notification_service.dart';

/// Provider for the NotificationService singleton
final notificationServiceProvider = Provider<NotificationService>((ref) {
  return NotificationService();
});

/// Provider for checking if notifications are enabled
final notificationsEnabledProvider = FutureProvider<bool>((ref) async {
  final notificationService = ref.read(notificationServiceProvider);
  return await notificationService.areNotificationsEnabled();
});

/// Provider for getting pending notifications
final pendingNotificationsProvider = FutureProvider<List<NotificationModel>>((ref) async {
  final notificationService = ref.read(notificationServiceProvider);
  return await notificationService.getPendingNotifications();
});
