// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'date_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$dateNotifierHash() => r'c48915421d28488ca40841971d9a8cd1066dded4';

/// See also [DateNotifier].
@ProviderFor(DateNotifier)
final dateNotifierProvider =
    AutoDisposeNotifierProvider<DateNotifier, DateTime>.internal(
  DateNotifier.new,
  name: r'dateNotifierProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$dateNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DateNotifier = AutoDisposeNotifier<DateTime>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
