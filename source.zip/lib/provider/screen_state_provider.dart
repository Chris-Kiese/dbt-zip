import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:uni_app/model/enums/screen_state.dart';

part 'screen_state_provider.g.dart';

@riverpod
class ScreenStateNotifier extends _$ScreenStateNotifier {
  @override
  ScreenState build() => ScreenState.details;

  void setScreenState(ScreenState screen) => state = screen;
}