// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'screen_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$screenStateNotifierHash() =>
    r'762530ada4c1693a8d74a1a96941c3396a14ff6f';

/// See also [ScreenStateNotifier].
@ProviderFor(ScreenStateNotifier)
final screenStateNotifierProvider =
    AutoDisposeNotifierProvider<ScreenStateNotifier, ScreenState>.internal(
  ScreenStateNotifier.new,
  name: r'screenStateNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$screenStateNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ScreenStateNotifier = AutoDisposeNotifier<ScreenState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
