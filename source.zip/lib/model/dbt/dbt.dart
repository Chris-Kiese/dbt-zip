import 'package:excel/excel.dart';
import 'package:isar/isar.dart';

part 'dbt.g.dart';

///Basic application Data class.
///This class is used to store & retrieve the data of the application, with the help of Isar code generation.
@embedded
class Dbt {
  Dbt({
    this.dissociation = 0,
    this.anxiety = 0,
    this.placeholderValue = 0,
    this.feeling,
    this.comment,
  });

  DateTime date = DateTime.now();
  int dissociation = 0;
  int anxiety = 0;
  int placeholderValue = 0;
  String? feeling;
  String? comment;
  void update({
    required int dissociation,
    required int anxiety,
    required int placeholderValue,
    required String feeling,
    String? comment,
  }) {
    this.dissociation = dissociation;
    this.anxiety = anxiety;
    this.placeholderValue = placeholderValue;
    this.feeling = feeling;
    this.comment = comment;
  }

  List<CellValue> toCellValues() {
    return [
      DateCellValue(year: date.year, month: date.month, day: date.day),
      TimeCellValue(hour: date.hour, minute: date.minute, second: date.second),
      IntCellValue(dissociation),
      IntCellValue(anxiety),
      IntCellValue(placeholderValue),
      TextCellValue(feeling ?? ''),
      TextCellValue(comment ?? ''),
    ];
  }
}

//Summary of dbts for a specific date. Used fot the statistics screen.
@Collection(accessor: "DbtSummaries")
class DbtSummary {
  DbtSummary({
    required this.date,
    required this.dbts,
  }) : id = Isar.autoIncrement;
  @Index(unique: true, replace: true)
  Id id;

  DateTime date;
  List<Dbt> dbts;

  int get dissociation =>
      dbts
          .map((e) => e.dissociation)
          .reduce((value, element) => value + element) ~/
      dbts.length;
  int get anxiety =>
      dbts.map((e) => e.anxiety).reduce((value, element) => value + element) ~/
      dbts.length;
  int get placeholderValue =>
      dbts
          .map((e) => e.placeholderValue)
          .reduce((value, element) => value + element) ~/
      dbts.length;

  void addDbt(Dbt dbt) {
    dbts = [
      ...dbts,
      dbt
    ]; //Assignment of list necessary or else the list will be fixed length after reboot.
  }

  void updateDbt(Dbt dbt) {
    final index = dbts.indexWhere((element) => element.date == dbt.date);
    if (index != -1) {
      dbts[index] = dbt;
    }
  }

  void removeDbt(Dbt dbt) {
    dbts.remove(dbt);
  }
}

typedef DbtSummaries = List<DbtSummary>;
