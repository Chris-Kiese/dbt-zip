// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dbt.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetDbtSummaryCollection on Isar {
  IsarCollection<DbtSummary> get DbtSummaries => this.collection();
}

const DbtSummarySchema = CollectionSchema(
  name: r'DbtSummary',
  id: 4385395870509557215,
  properties: {
    r'anxiety': PropertySchema(
      id: 0,
      name: r'anxiety',
      type: IsarType.long,
    ),
    r'date': PropertySchema(
      id: 1,
      name: r'date',
      type: IsarType.dateTime,
    ),
    r'dbts': PropertySchema(
      id: 2,
      name: r'dbts',
      type: IsarType.objectList,
      target: r'Dbt',
    ),
    r'dissociation': PropertySchema(
      id: 3,
      name: r'dissociation',
      type: IsarType.long,
    ),
    r'placeholderValue': PropertySchema(
      id: 4,
      name: r'placeholderValue',
      type: IsarType.long,
    )
  },
  estimateSize: _dbtSummaryEstimateSize,
  serialize: _dbtSummarySerialize,
  deserialize: _dbtSummaryDeserialize,
  deserializeProp: _dbtSummaryDeserializeProp,
  idName: r'id',
  indexes: {},
  links: {},
  embeddedSchemas: {r'Dbt': DbtSchema},
  getId: _dbtSummaryGetId,
  getLinks: _dbtSummaryGetLinks,
  attach: _dbtSummaryAttach,
  version: '3.1.0+1',
);

int _dbtSummaryEstimateSize(
  DbtSummary object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.dbts.length * 3;
  {
    final offsets = allOffsets[Dbt]!;
    for (var i = 0; i < object.dbts.length; i++) {
      final value = object.dbts[i];
      bytesCount += DbtSchema.estimateSize(value, offsets, allOffsets);
    }
  }
  return bytesCount;
}

void _dbtSummarySerialize(
  DbtSummary object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.anxiety);
  writer.writeDateTime(offsets[1], object.date);
  writer.writeObjectList<Dbt>(
    offsets[2],
    allOffsets,
    DbtSchema.serialize,
    object.dbts,
  );
  writer.writeLong(offsets[3], object.dissociation);
  writer.writeLong(offsets[4], object.placeholderValue);
}

DbtSummary _dbtSummaryDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = DbtSummary(
    date: reader.readDateTime(offsets[1]),
    dbts: reader.readObjectList<Dbt>(
          offsets[2],
          DbtSchema.deserialize,
          allOffsets,
          Dbt(),
        ) ??
        [],
  );
  object.id = id;
  return object;
}

P _dbtSummaryDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLong(offset)) as P;
    case 1:
      return (reader.readDateTime(offset)) as P;
    case 2:
      return (reader.readObjectList<Dbt>(
            offset,
            DbtSchema.deserialize,
            allOffsets,
            Dbt(),
          ) ??
          []) as P;
    case 3:
      return (reader.readLong(offset)) as P;
    case 4:
      return (reader.readLong(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _dbtSummaryGetId(DbtSummary object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _dbtSummaryGetLinks(DbtSummary object) {
  return [];
}

void _dbtSummaryAttach(IsarCollection<dynamic> col, Id id, DbtSummary object) {
  object.id = id;
}

extension DbtSummaryQueryWhereSort
    on QueryBuilder<DbtSummary, DbtSummary, QWhere> {
  QueryBuilder<DbtSummary, DbtSummary, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }
}

extension DbtSummaryQueryWhere
    on QueryBuilder<DbtSummary, DbtSummary, QWhereClause> {
  QueryBuilder<DbtSummary, DbtSummary, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterWhereClause> idNotEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterWhereClause> idGreaterThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension DbtSummaryQueryFilter
    on QueryBuilder<DbtSummary, DbtSummary, QFilterCondition> {
  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> anxietyEqualTo(
      int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'anxiety',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      anxietyGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'anxiety',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> anxietyLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'anxiety',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> anxietyBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'anxiety',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dateEqualTo(
      DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dateGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dateLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dateBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'date',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dbtsLengthEqualTo(
      int length) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'dbts',
        length,
        true,
        length,
        true,
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dbtsIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'dbts',
        0,
        true,
        0,
        true,
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dbtsIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'dbts',
        0,
        false,
        999999,
        true,
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      dbtsLengthLessThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'dbts',
        0,
        true,
        length,
        include,
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      dbtsLengthGreaterThan(
    int length, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'dbts',
        length,
        include,
        999999,
        true,
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dbtsLengthBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.listLength(
        r'dbts',
        lower,
        includeLower,
        upper,
        includeUpper,
      );
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      dissociationEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'dissociation',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      dissociationGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'dissociation',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      dissociationLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'dissociation',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      dissociationBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'dissociation',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      placeholderValueEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'placeholderValue',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      placeholderValueGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'placeholderValue',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      placeholderValueLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'placeholderValue',
        value: value,
      ));
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition>
      placeholderValueBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'placeholderValue',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension DbtSummaryQueryObject
    on QueryBuilder<DbtSummary, DbtSummary, QFilterCondition> {
  QueryBuilder<DbtSummary, DbtSummary, QAfterFilterCondition> dbtsElement(
      FilterQuery<Dbt> q) {
    return QueryBuilder.apply(this, (query) {
      return query.object(q, r'dbts');
    });
  }
}

extension DbtSummaryQueryLinks
    on QueryBuilder<DbtSummary, DbtSummary, QFilterCondition> {}

extension DbtSummaryQuerySortBy
    on QueryBuilder<DbtSummary, DbtSummary, QSortBy> {
  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> sortByAnxiety() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'anxiety', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> sortByAnxietyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'anxiety', Sort.desc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> sortByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> sortByDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.desc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> sortByDissociation() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dissociation', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> sortByDissociationDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dissociation', Sort.desc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> sortByPlaceholderValue() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'placeholderValue', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy>
      sortByPlaceholderValueDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'placeholderValue', Sort.desc);
    });
  }
}

extension DbtSummaryQuerySortThenBy
    on QueryBuilder<DbtSummary, DbtSummary, QSortThenBy> {
  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByAnxiety() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'anxiety', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByAnxietyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'anxiety', Sort.desc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.desc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByDissociation() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dissociation', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByDissociationDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'dissociation', Sort.desc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy> thenByPlaceholderValue() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'placeholderValue', Sort.asc);
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QAfterSortBy>
      thenByPlaceholderValueDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'placeholderValue', Sort.desc);
    });
  }
}

extension DbtSummaryQueryWhereDistinct
    on QueryBuilder<DbtSummary, DbtSummary, QDistinct> {
  QueryBuilder<DbtSummary, DbtSummary, QDistinct> distinctByAnxiety() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'anxiety');
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QDistinct> distinctByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'date');
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QDistinct> distinctByDissociation() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'dissociation');
    });
  }

  QueryBuilder<DbtSummary, DbtSummary, QDistinct> distinctByPlaceholderValue() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'placeholderValue');
    });
  }
}

extension DbtSummaryQueryProperty
    on QueryBuilder<DbtSummary, DbtSummary, QQueryProperty> {
  QueryBuilder<DbtSummary, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<DbtSummary, int, QQueryOperations> anxietyProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'anxiety');
    });
  }

  QueryBuilder<DbtSummary, DateTime, QQueryOperations> dateProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'date');
    });
  }

  QueryBuilder<DbtSummary, List<Dbt>, QQueryOperations> dbtsProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'dbts');
    });
  }

  QueryBuilder<DbtSummary, int, QQueryOperations> dissociationProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'dissociation');
    });
  }

  QueryBuilder<DbtSummary, int, QQueryOperations> placeholderValueProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'placeholderValue');
    });
  }
}

// **************************************************************************
// IsarEmbeddedGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

const DbtSchema = Schema(
  name: r'Dbt',
  id: -5708698045533279967,
  properties: {
    r'anxiety': PropertySchema(
      id: 0,
      name: r'anxiety',
      type: IsarType.long,
    ),
    r'comment': PropertySchema(
      id: 1,
      name: r'comment',
      type: IsarType.string,
    ),
    r'date': PropertySchema(
      id: 2,
      name: r'date',
      type: IsarType.dateTime,
    ),
    r'dissociation': PropertySchema(
      id: 3,
      name: r'dissociation',
      type: IsarType.long,
    ),
    r'feeling': PropertySchema(
      id: 4,
      name: r'feeling',
      type: IsarType.string,
    ),
    r'placeholderValue': PropertySchema(
      id: 5,
      name: r'placeholderValue',
      type: IsarType.long,
    )
  },
  estimateSize: _dbtEstimateSize,
  serialize: _dbtSerialize,
  deserialize: _dbtDeserialize,
  deserializeProp: _dbtDeserializeProp,
);

int _dbtEstimateSize(
  Dbt object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.comment;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.feeling;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  return bytesCount;
}

void _dbtSerialize(
  Dbt object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.anxiety);
  writer.writeString(offsets[1], object.comment);
  writer.writeDateTime(offsets[2], object.date);
  writer.writeLong(offsets[3], object.dissociation);
  writer.writeString(offsets[4], object.feeling);
  writer.writeLong(offsets[5], object.placeholderValue);
}

Dbt _dbtDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = Dbt(
    anxiety: reader.readLongOrNull(offsets[0]) ?? 0,
    comment: reader.readStringOrNull(offsets[1]),
    dissociation: reader.readLongOrNull(offsets[3]) ?? 0,
    feeling: reader.readStringOrNull(offsets[4]),
    placeholderValue: reader.readLongOrNull(offsets[5]) ?? 0,
  );
  object.date = reader.readDateTime(offsets[2]);
  return object;
}

P _dbtDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLongOrNull(offset) ?? 0) as P;
    case 1:
      return (reader.readStringOrNull(offset)) as P;
    case 2:
      return (reader.readDateTime(offset)) as P;
    case 3:
      return (reader.readLongOrNull(offset) ?? 0) as P;
    case 4:
      return (reader.readStringOrNull(offset)) as P;
    case 5:
      return (reader.readLongOrNull(offset) ?? 0) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

extension DbtQueryFilter on QueryBuilder<Dbt, Dbt, QFilterCondition> {
  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> anxietyEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'anxiety',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> anxietyGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'anxiety',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> anxietyLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'anxiety',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> anxietyBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'anxiety',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'comment',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'comment',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'comment',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'comment',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'comment',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'comment',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'comment',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'comment',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentContains(String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'comment',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentMatches(String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'comment',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'comment',
        value: '',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> commentIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'comment',
        value: '',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dateEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dateGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dateLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dateBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'date',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dissociationEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'dissociation',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dissociationGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'dissociation',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dissociationLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'dissociation',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> dissociationBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'dissociation',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'feeling',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'feeling',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'feeling',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'feeling',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'feeling',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'feeling',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'feeling',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'feeling',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingContains(String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'feeling',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingMatches(String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'feeling',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'feeling',
        value: '',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> feelingIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'feeling',
        value: '',
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> placeholderValueEqualTo(
      int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'placeholderValue',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> placeholderValueGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'placeholderValue',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> placeholderValueLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'placeholderValue',
        value: value,
      ));
    });
  }

  QueryBuilder<Dbt, Dbt, QAfterFilterCondition> placeholderValueBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'placeholderValue',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension DbtQueryObject on QueryBuilder<Dbt, Dbt, QFilterCondition> {}
