///Enum to set body of [HomePage] to correct screen.
enum ScreenState {
  form, //Form to add or update dbt
  details, //Details of selected dbt
  statistics //Statistics & graphics about all dbts
}