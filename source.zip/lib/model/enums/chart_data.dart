///Enum to set which data the graph should represent in the [StatisticsPage].
enum ChartData { anxiety, dissociation, placeholderValue, all }
