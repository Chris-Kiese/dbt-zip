///Enum to set the time range of the chart in the [StatisticsPage].
enum ChartRange {
  week, //Show current Week
  month, //Show current Month
  year, //Show current Year
  all, //Show all dbts
}