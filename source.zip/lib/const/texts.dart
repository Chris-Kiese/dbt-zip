//Basic texts
const appName = 'DBT Ulm';
const save = 'Speichern';
const update = 'Aktualisieren';
const close = 'Schließen';

//DBT FORM
const labelEmotion = 'Emotion';
const usedSkillsHint = 'Ereignis? Welche Skills hast du angewendet?\nAnregungen für neue Skills gibt es auch im Manual.';
const labelDissociation = 'Dissoziation';
const labelAnxiety = 'Anspannung';
const labelMood = 'Stimmung';
const dissociationExplanation = 'Bitte gib an, wie stark du aktuell dissoziative Symptome erlebst, zum Beispiel das Gefühl, dass dein Körper sich nicht wie dein eigener anfühlt oder dass Dinge oder Menschen um dich herum unwirklich erscheinen.';
const anxietyExplanation = 'Bitte gib an, wie stark du im Moment unangenehme innere Anspannung verspürst.';
const moodExplanation = 'Wie positiv/negativ ist deine Stimmung im Moment?';

//Home screen
const datePickerHelpText = 'Datum auswählen';
const datePickerCancelText = 'Abbrechen';
const datePickerConfirmText = 'Auswählen';

//DBT Table
const noEntryText = 'Es gibt noch keinen Eintrag.';
const timeHeader = 'Zeit';
const dissociationHeader = 'Dissoziation';
const anxietyHeader = 'Anspannung';
const emotionHeader = 'Emotion';
const skillsDialogTitle = 'Ereignis? Welche Skills angewandt?\nAnregungen für neue Skills gibt es auch im Manual.';

//Statistics
const timeRangeLabel = 'Zeitraum';
const dataLabel = 'Daten';
const weekLabel = 'Woche';
const monthLabel = 'Monat';
const yearLabel = 'Jahr';
const totalLabel = 'Gesamt';
const allDataLabel = 'Alles';
