const moodMapping = {
  -5: 'Sehr negativ',
  -4: 'Negativ',
  -3: 'Etwas negativ',
  -2: 'Leicht negativ',
  -1: 'Ein wenig negativ',
  0: 'Neutral',
  1: 'Ein wenig positiv',
  2: 'Leicht positiv',
  3: 'Etwas positiv',
  4: 'Positiv',
  5: 'Sehr positiv',
};

const feelingList = [
  'Keine Angabe',
  'Angst',
  'Wut/Ärger',
  'Einsamkeit',
  'Ekel',
  'Freude',
  'Neid/Eifersucht',
  'Ohnmacht',
  'Scham',
  'Schuld',
  'Stolz',
  'Trauer',
  'Zuversicht'
];