import 'package:flutter/material.dart';

final primaryColor = Colors.teal[200];
final secondaryColor = Colors.teal[200];

const btmBarActivatedColor = Colors.teal;
const btmBarDeactivatedColor = Colors.white;

final anxietyColor = Colors.red[300];
final dissociationColor = Colors.blue[300];
final placeholderValueColor = Colors.green[300];

const displayTextStyle = TextStyle(
  fontSize: 17,
  color: Colors.black,
);

final appTheme = ThemeData(
  colorScheme: ColorScheme.fromSwatch().copyWith(
    primary: primaryColor,
    secondary: Colors.black,
  ),
  scaffoldBackgroundColor: Colors.white,
  floatingActionButtonTheme:
      FloatingActionButtonThemeData(backgroundColor: primaryColor),
  datePickerTheme: DatePickerThemeData(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    cancelButtonStyle: ButtonStyle(
      textStyle: WidgetStateProperty.all(const TextStyle(color: Colors.black)),
    ),
    backgroundColor: primaryColor,
  ),
  sliderTheme: SliderThemeData(
    activeTrackColor: primaryColor,
    inactiveTrackColor: Colors.grey[300],
    thumbColor: primaryColor,
    valueIndicatorColor: primaryColor,
    valueIndicatorTextStyle: const TextStyle(color: Colors.white),
  ),
  buttonTheme: ButtonThemeData(
    buttonColor: primaryColor,
    textTheme: ButtonTextTheme.normal,
  ),
  dropdownMenuTheme: DropdownMenuThemeData(
      menuStyle: MenuStyle(
        backgroundColor: WidgetStateProperty.all(primaryColor),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: primaryColor!)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: primaryColor!)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: primaryColor!)),
      )),
  visualDensity: VisualDensity.adaptivePlatformDensity,
);
